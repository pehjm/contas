/*
 * Decompiled with CFR 0.152.
 */
package com.graphbuilder.math;

import com.graphbuilder.math.Expression;
import com.graphbuilder.math.FuncMap;
import com.graphbuilder.math.OpNode;
import com.graphbuilder.math.VarMap;

public class SubNode
extends OpNode {
    public SubNode(Expression leftChild, Expression rightChild) {
        super(leftChild, rightChild);
    }

    public double eval(VarMap v, FuncMap f) {
        double a = this.leftChild.eval(v, f);
        double b = this.rightChild.eval(v, f);
        return a - b;
    }

    public String getSymbol() {
        return "-";
    }
}

